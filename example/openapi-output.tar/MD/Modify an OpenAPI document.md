# Modify an OpenAPI document

**Article • 05/24/2024**

The PetStore API described in Create an OpenAPI document has only one path forgetting all pets. Imagine the API adds the capability to add a pet to the store.This example adds a new path to the OpenAPI document to describe a new endpoint foradding a pet to the store.

C#

    using Microsoft.OpenApi.Models;using Microsoft.OpenApi.Readers;using Microsoft.OpenApi.Writers;// Load the existing OpenAPI document from a YAML fileusing var streamReader = new StreamReader("pet-store.yaml");var reader = new OpenApiStreamReader();var document = reader.Read(streamReader.BaseStream, out var diagnostic);// Add a new property to the Pet schemavar categoryProperty = new OpenApiSchema{ Type = "object", Properties = new Dictionary<string, OpenApiSchema> { ["id"] = new OpenApiSchema { Type = "integer", }, ["name"] = new OpenApiSchema { Type = "string", }, },};document.Components.Schemas["Pet"].Properties.Add("category", categoryProperty);// Add a new pathvar newPetPath = new OpenApiPathItem{ Operations = new Dictionary<OperationType, OpenApiOperation> { [OperationType.Post] = new OpenApiOperation { Description = "Add a new pet", RequestBody = new OpenApiRequestBody { Content = new Dictionary<string, OpenApiMediaType>
    { ["application/json"] = new OpenApiMediaType { Schema = new OpenApiSchema { Reference = new OpenApiReference { Type = ReferenceType.Schema, Id = "Pet", }, }, }, }, Required = true, // Indicates that the body is required }, Responses = new OpenApiResponses { ["201"] = new OpenApiResponse { Description = "Pet created successfully", }, }, }, },};// Add the new path to the documentdocument.Paths.Add("/pets/post", newPetPath);// Serialize and save the modified OpenAPI document to a new fileusing var streamWriter = new StreamWriter("updated-pet-store.yaml");var writer = new OpenApiYamlWriter(streamWriter);document.SerializeAsV3(writer);Console.WriteLine("PetStore OpenAPI document updated.");
The following YAML snippet is how the modified OpenAPI description for PetStoreservice looks now:

YAML

    openapi: 3.0.1info: title: PetStore API version: 1.0.0servers: - url: https://api.petstore.compaths: /pets: get: description: Get all pets responses: '200': description: A list of pets
    content: application/json: schema: type: array items: $ref: '#/components/schemas/Pet' /pets/post: post: description: Add a new pet requestBody: content: application/json: schema: $ref: '#/components/schemas/Pet' required: true responses: '201': description: Pet created successfullycomponents: schemas: Pet: type: object properties: name: type: string category: type: object properties: id: type: integer name: type: string
## Next steps

See Converting an OpenAPI document to learn how to use the OpenAPI.NETlibrary to convert between YAML and JSON formats.
