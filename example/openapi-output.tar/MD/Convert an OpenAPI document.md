# Convert an OpenAPI document

**Article • 05/24/2024**

OpenAPI.NET has the ability to convert OpenAPI documents between different formats,such as YAML or JSON. This capability can be useful when you need to share orcollaborate on an OpenAPI document with others who prefer a different format.Here's an example of how you can convert an OpenAPI document from YAML to JSON

    using OpenAPI.NET.
This example converts the OpenAPI document created and modified in the previousexamples from YAML to JSON.

C#

    using Microsoft.OpenApi.Readers;using Microsoft.OpenApi.Writers;// Load the existing OpenAPI document from a YAML fileusing var streamReader = new StreamReader("updated-pet-store.yaml");var reader = new OpenApiStreamReader();var document = reader.Read(streamReader.BaseStream, out var diagnostic);// Serialize and save the OpenAPI document to a JSON fileusing var streamWriter = new StreamWriter("updated-pet-store.json");var writer = new OpenApiJsonWriter(streamWriter);document.SerializeAsV3(writer);Console.WriteLine("OpenAPI document converted from YAML to JSON.");
Compare the original YAML with the new JSON.

## YAML

YAML

    openapi: 3.0.1info: title: PetStore API version: 1.0.0servers: - url: https://api.petstore.compaths: /pets: get: description: Get all pets responses:
    '200': description: A list of pets content: application/json: schema: type: array items: $ref: '#/components/schemas/Pet' /pets/post: post: description: Add a new pet requestBody: content: application/json: schema: $ref: '#/components/schemas/Pet' required: true responses: '201': description: Pet created successfullycomponents: schemas: Pet: type: object properties: name: type: string category: type: object properties: id: type: integer name: type: string
## JSON

JSON

    { "openapi": "3.0.1", "info": { "title": "PetStore API", "version": "1.0.0" }, "servers": [ { "url": "https://api.petstore.com" } ], "paths": { "/pets": {
    "get": { "description": "Get all pets", "responses": { "200": { "description": "A list of pets", "content": { "application/json": { "schema": { "type": "array", "items": { "$ref": "#/components/schemas/Pet" } } } } } } } }, "/pets/post": { "post": { "description": "Add a new pet", "requestBody": { "content": { "application/json": { "schema": { "$ref": "#/components/schemas/Pet" } } }, "required": true }, "responses": { "201": { "description": "Pet created successfully" } } } } }, "components": { "schemas": { "Pet": { "type": "object", "properties": { "name": { "type": "string" }, "category": { "type": "object", "properties": { "id": { "type": "integer" }, "name": {
    "type": "string" } } } } } } }}
