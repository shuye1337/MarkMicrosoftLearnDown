# Create an OpenAPI document

**Article • 05/24/2024**

The `OpenApiDocument` class contains methods and properties that developers use tocreate an OpenAPI document in code.This example defines a simple PetStore API definition that allows users to view pets in anonline store. It adds a GET operation for a single path (` /pets` ), and defines the `Pet` typereturned by the API.

C#

    using Microsoft.OpenApi.Models;using Microsoft.OpenApi.Writers;// Create an OpenAPI document for the PetStore APIvar document = new OpenApiDocument{ Info = new OpenApiInfo { Title = "PetStore API", Version = "1.0.0", }, Servers = [ new OpenApiServer { Url = "https://api.petstore.com" }, ], Paths = new OpenApiPaths { ["/pets"] = new OpenApiPathItem { Operations = new Dictionary<OperationType, OpenApiOperation> { [OperationType.Get] = new OpenApiOperation { Description = "Get all pets", Responses = new OpenApiResponses { ["200"] = new OpenApiResponse { Description = "A list of pets", Content = new Dictionary<string, OpenApiMediaType> { ["application/json"] = new OpenApiMediaType { Schema = new OpenApiSchema { Type = "array", Items = new OpenApiSchema
    { Reference = new OpenApiReference { Type = ReferenceType.Schema, Id = "Pet", }, }, }, }, }, }, }, }, }, }, }, Components = new OpenApiComponents { Schemas = new Dictionary<string, OpenApiSchema> { ["Pet"] = new OpenApiSchema { Type = "object", Properties = new Dictionary<string, OpenApiSchema> { ["name"] = new OpenApiSchema { Type = "string", }, }, }, }, },};// Serialize the OpenAPI document to a YAML fileusing var streamWriter = new StreamWriter("pet-store.yaml");var writer = new OpenApiYamlWriter(streamWriter);document.SerializeAsV3(writer);Console.WriteLine("PetStore OpenAPI document created and saved.");
Here's the resulting OpenAPI description for our PetStore service:

YAML

    openapi: 3.0.1info: title: PetStore API version: 1.0.0servers: - url: https://api.petstore.compaths: /pets:
    get: description: Get all pets responses: '200': description: A list of pets content: application/json: schema: type: array items: $ref: '#/components/schemas/Pet'components: schemas: Pet: type: object properties: name: type: string
## Next steps

See Modifying an OpenAPI document to learn how to add a new path to thisOpenAPI document.See Converting an OpenAPI document to learn how to use the OpenAPI.NETlibrary to convert between YAML and JSON formats.
