# References in OpenAPI documents

OpenAPI uses the keyword `$ref` to enable referencing and reusing existing objects defined in anOpenAPI description. However, there are many different ways to use this keyword and not all aresupported by the OpenAPI.NET library. Also, OpenAPI 3.1 formalized the distinction between theuse of the `$ref` keyword in a Schema object vs elsewhere in an OpenAPI description. To bestunderstand how to use `$ref` it is helpful to be aware of its capabilities and the current limitationsof OpenAPI.Net.

### Reference Objects

Prior to OpenAPI v3.1, Reference Objects was the term for all usages of `$ref` within OpenAPIdescriptions. However, when OpenAPI v3.1 introduced support for JSON Schema beyond thedraft-4 version, it became necessary to allow the use of `$ref` within Schema Objects to follow therules of JSON Schema and all other uses in OpenAPI descriptions would be considered ReferenceObjects. Therefore, this section only describes the rules for `$ref` keywords that are not in aSchema Object.

### Where Reference Objects can be used

Reference objects can appear in one of two places. Either in place of an inline object, or a mapvalue in the components section.This example below shows a common usage pattern of referencing a shared parameter object

    using a reference object.
**YAML**

    openapi: 3.1.0info: title: Example of reference object pointing to a parameter version: 1.0.0paths: /item: get: parameters: $ref: '#/components/parameters/size'components: parameters: size: name: size in: query
    schema: type: number
The following example shows a way to externalize security schemes using a reference object in acomponent. This is necessary because security requirement objects do not allow referencing

    using an external URI.
**YAML**

    openapi: 3.1.0info: title: Example of reference object in a component object version: 1.0.0paths: /item: get: security: - customapikey: []components: securitySchemes: customapikey: $ref: ./commonSecuritySchemes/customapikey.json#/components/securitySchemes/customapikey
### Targeting Mechanisms used in Reference objects

Reference objects can use a relative reference with just a fragment identifier to point to an OASComponent.

**YAML**

    openapi: 3.1.0info: title: Example of reference object pointing to a pathitem version: 1.0.0paths: /jobs/{id}: post: requestBody: $ref: '#/components/requestBodies/job'components: requestBodies: job: required: true content: application/json: {}
Reference objects can reference OAS components in another OpenAPI document.

**YAML**

    openapi: 3.1.0info: title: Example of reference object pointing to an example object in an OpenAPI document version: 1.0.0paths: /items: get: responses: 200: description: Ok content: application/json: examples: item-list: $ref: './examples.yaml#/components/examples/item-list'
**YAML**

    # file for examples (examples.yaml)openapi: 3.1.0info: title: OpenAPI document containing examples for reuse version: 1.0.0components: examples: item-list: value: - name: thing description: a thing
For completeness, Reference Objects can also point to targets in a JSON/YAML document thatcontain properly formed OpenAPI objects, but is not a complete OpenApi document. We refer tothese as OpenAPI "fragments". Currently OpenAPI.NET does not support referencing OpenAPIfragments.

**YAML**

    openapi: 3.1.0info: title: Example of reference object pointing to a parameter version: 1.0.0paths: /items: get: responses: 200: description: Ok
    content: application/json: examples: item-list: $ref: './examples.yaml#/item-list'
**YAML**

    # file for example fragments (examples.yaml)item-list: value: - name: thing description: a thing
### What types Reference objects can target

Reference objects can be used to target the follow OAS types: parameter, response, requestBody,example, header, securityScheme, link, callback and pathItem. In OpenAPI 3.0, they also canreference schema objects.

### JSON Schema $refs in OpenAPI descriptions

From OpenAPI 3.1 onwards, a `$ref` inside a Schema object is not considered an OpenAPIReference Object. It behaves like a JSON Schema reference, specifically a JSON Schema 2020-12reference, unless the dialect is changed for the OpenAPI document.

### Where can JSON Schema references be used

JSON Schema references can be used in the following locations:

at the root of an inline schemain a subschema of an inline schemaat the root of a component schemain a subschema of a component schema

**Root of an inline schema**

**YAML**

    openapi: 3.1.0info: title: Reference in at the root of an inline schema version: 1.0.0
    paths: /item: get: responses: 200: description: ok content: application/json: schema: $ref: '#/components/schemas/item'components: schemas: item: type: object
**In a subschema of an inline schema**

**YAML**

    openapi: 3.1.0info: title: Reference in at the root of an inline schema version: 1.0.0paths: /items: get: responses: 200: description: ok content: application/json: schema: type: array items: $ref: '#/components/schemas/item'components: schemas: item: type: object
**At the root of a component schema**

**YAML**

    openapi: 3.1.0info: title: Reference at the root of a component schema version: 1.0.0paths: /items: get:
    responses: 200: description: ok content: application/json: schema: type: array items: $ref: '#/components/schemas/specialitem'components: schemas: specialitem: # Use the item type but provide a different title for the type title: Special Item $ref: "#/components/schemas/item" item: title: Item type: object
**In a subschema of a component schema**

**YAML**

    openapi: 3.1.0info: title: Reference in a subschema of an component schema version: 1.0.0paths: /items: get: responses: 200: description: ok content: application/json: schema: $ref: '#/components/schemas/items'components: schemas: items: type: array items: $ref: '#/components/schemas/item' item: type: object
**References local to a JSON Schema Resource defined by an****OpenAPI Schema**JSON Schema defines the concept of a JSON Schema Resource which is identified by a URI. $refvalues can be specified relative to the JSON Schema Resource. Each OpenAPI schema object can

be considered a JSON Schema Resource.In this example schema "a" is a JSON Schema resource and the reference in the "b" property ofthe "c" object is relative to the JSON Schema resource "a". Unfortunately, OpenAPI 3.1 has nowell defined URIs for OpenAPI Schemas. This is resolved in OpenAPI 3.2 with the introduction of anew top level "$self" property.

**YAML**

    components: schemas: # this component schema is ALSO a JSON schema resource # therefore, the ref is relative to this schema. # this would also work if the whole tree is a schema inside a media type schema, etc... a: type: - object - 'null' properties: b: type: - object - 'null' properties: c: type: - object - 'null' properties: b: $ref: '#/properties/b'
**References local to a JSON Schema Resource defined by a $id [Not****currently supported]**

**YAML**

    components: schemas: a: type: - object - 'null' additionalProperties: false properties: b: type: - object - 'null'
    additionalProperties: false properties: c: # this is similar to the prior example, but the $id here turns this specific schema in a resource # it effectively defines a "new root" for relative lookups. $id: 'http://example.org/c' type: - object - 'null' additionalProperties: false properties: b: $ref: '#/properties/d' d: type: string
### What kinds of JSON Schema references exist

JSON Schema references can use either a locator or an identifier. Locators indicate where to findthe target schema based on the name and structure of documents. However, identifiers areopaque URIs that match to the identifier of a JSON schema that has a $id either explicitly orimplicitly by inheriting an identity from its parent.

### What can a JSON Schema locator reference target

An internal componentAn internal component subschemaAn internal inline subschemaAn external OpenApi document componentAn external inline subchemaAn external inline subchema using anchor [Not currently supported]An external fragment [Not supported]

**An internal component**

**YAML**

    openapi: 3.1.0info: title: Reference to an internal component version: 1.0.0paths: /item: get: responses:
    200: description: ok content: application/json: schema: $ref: '#/components/schemas/item'components: schemas: item: type: object
**An internal component subschema**

**YAML**

    openapi: 3.1.0info: title: Reference to an internal component version: 1.0.0paths: /person/{id}: get: responses: 200: description: ok content: application/json: schema: $ref: '#/components/schemas/person' /person/{id}/address: get: responses: 200: description: ok content: application/json: schema: $ref: '#/components/schemas/person/properties/address'components: schemas: person: type: object properties: name: type: string address: type: object properties: street: type: string city: type: string
**An external OpenApi document component**

**YAML**

    openapi: 3.1.0info: title: Reference to an external OpenApi document component version: 1.0.0paths: /person/{id}: get: responses: 200: description: ok content: application/json: schema: # the URI is assumed to be relative according to RFC 3986 $ref: 'OAS-schemas.yaml#/components/schemas/person'
**YAML**

    # OAS-schemas.yaml fileopenapi: 3.1.0info: title: OpenAPI document containing reusable components version: 1.0.0components: schemas: person: type: object properties: name: type: string address: type: object properties: street: type: string city: type: string
**An external inline subchema**

**YAML**

    openapi: 3.1.0info: title: Reference to an external OpenApi document component version: 1.0.0paths:
    /person/{id}: get: responses: 200: description: ok content: application/json: schema: $ref: 'OAS-schemas.yaml#/components/schemas/person/properties/address'
**YAML**

    # OAS-schemas.yaml fileopenapi: 3.1.0info: title: OpenAPI document containing reusable components version: 1.0.0components: schemas: person: type: object properties: name: type: string address: type: object properties: street: type: string city: type: string
**An external inline subchema using an anchor [Not currently supported]**We accept pull requests.

**YAML**

    openapi: 3.1.0info: title: Reference to an external OpenApi document component version: 1.0.0paths: /person/{id}: get: responses: 200: description: ok content: application/json:
    schema: $ref: 'OAS-schemas.yaml#address'
**YAML**

    # OAS-schemas.yaml fileopenapi: 3.1.0info: title: OpenAPI document containing reusable components version: 1.0.0components: schemas: person: type: object properties: name: type: string address: $anchor: address type: object properties: street: type: string city: type: string
**An external fragment [Not supported]**

**YAML**

    openapi: 3.1.0info: title: Reference to an external OpenApi document component version: 1.0.0paths: /person/{id}: get: responses: 200: description: ok content: application/json: schema: $ref: 'OAS-schemas.yaml#/person/properties/address'
**YAML**

    # OAS-schemas.yaml fileperson: type: object
    properties: name: type: string address: type: object properties: street: type: string city: type: string
### What can a JSON Schema identifier reference target

Reference an internal component using a $idReference an internal subschema using a $id [Not supported yet]Reference an external component schema using a $id

**Reference an internal component using a $id**

**YAML**

    openapi: 3.1.0info: title: Reference an internal component using id version: 1.0.0paths: /person/{id}: get: responses: 200: description: ok content: application/json: schema: $ref: 'https://schemas.acme.org/person'components: schemas: person: $id: 'https://schemas.acme.org/person' type: object properties: name: type: string address: type: object properties: street: type: string city: type: string
**Reference an internal subschema using a $id [Not supported yet]**

**YAML**

    openapi: 3.1.0info: title: Reference an internal subschema using id version: 1.0.0paths: /person/{id}/address: get: responses: 200: description: ok content: application/json: schema: $ref: 'https://schemas.acme.org/address'components: schemas: person: $id: 'https://schemas.acme.org/person' type: object properties: name: type: string address: # this is equivalent to https://schemas.acme.org/address because # https://schemas.acme.org/person does NOT end up with / (RFC 3986) $id: 'address' type: object properties: street: type: string city: type: string
**Reference external component schemas using a $id**External component schemas are referenced in the exact same way as internal componentschemas. External subschemas that rely on their own `$id` are not currently supported.

### $dynamicAnchor and $dynamicRef [Notcurrently supported]

    JSON Schema 2020-12, which is the basis for OpenAPI 3.1 schemas, introduces $dynamicAnchor
and `$dynamicRef` as a mechanism for building extensible, generic schemas. They work together as

overridable extension hooks:

    $dynamicAnchor declares a named placeholder anchor in a schema. Any parent schema that
references it can redefine the anchor to specialize behavior.

    $dynamicRef references a dynamic anchor. Unlike $ref , it does not resolve statically.
Instead, evaluation looks back through the stack of schema resources traversed so far, andjumps to the **first** encountered definition of that anchor. This allows a specializing schemato override the referenced subschema.

This is analogous to generic type parameters in programming languages such as C++ templatesor Java generics.OpenAPI.NET exposes `$dynamicAnchor` and `$dynamicRef` as properties on the schema model, butdynamic reference resolution is not currently implemented.The following example defines a generic `collection` schema whose item type can be overriddenby a more specialized schema.

**YAML**

    openapi: 3.1.0info: title: Generic collection schema using $dynamicAnchor and $dynamicRef version: 1.0.0components: schemas: # A generic, reusable collection schema. # The item type is left open and can be overridden by a specializing # schema that redefines the "collection-item" dynamic anchor. collection: $id: 'https://schemas.acme.org/collection' type: array items: $dynamicRef: '#collection-item' $defs: default: $comment: Default declaration to satisfy the bookending requirement $dynamicAnchor: collection-item # A specialized collection schema that constrains items to strings. # It references the generic schema and overrides the dynamic anchor. string-collection: $ref: 'https://schemas.acme.org/collection' $defs: collection-item: $dynamicAnchor: collection-item type: string
In this example:

    collection uses $dynamicRef: '#collection-item' to declare that each array item should
validate against whatever `collection-item` resolves to at runtime.

    The $defs/default subschema in collection declares the $dynamicAnchor: collection-item
placeholder. This satisfies the *bookending requirement*: the base schema that uses

    $dynamicRef must itself provide a $dynamicAnchor with the same name, even if it imposes
no constraints.

    string-collection uses $ref to extend collection and redefines collection-item in its
own `$defs` with `type: string` .When `string-collection` is evaluated, the `$dynamicRef` in `collection` resolves to the

    collection-item anchor defined in string-collection , effectively constraining all array
items to be strings.

### $ref in PathItem Objects

This scenario is supported in OpenAPI.NET.

**YAML**

    openapi: 3.1.0info: title: Example of reference object pointing to a pathitem version: 1.0.0paths: /jobs/{id}: $ref: '#/components/pathItems/job'components: pathItems: job: get: {} patch: {} delete: {}
**Last updated on 06/29/2026**
