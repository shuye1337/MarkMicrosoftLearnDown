# Earlier-version serialization considerations

OpenAPI.NET can deserialize newer OpenAPI documents into an object model and serialize thatobject model as an earlier OpenAPI version. This conversion is useful for interoperability, butOpenAPI 2.0 and OpenAPI 3.0 don't support every feature in later OpenAPI versions or in theOpenAPI.NET object model.The output format, JSON or YAML, doesn't change which information is preserved. The target

    OpenApiSpecVersion determines the conversion behavior.
Information can be handled in four ways when you serialize to an older version:

ﾉ**Expand table**

**Result****Meaning**Preserved nativelyThe target OpenAPI version has an equivalent field.Preserved as anextension

OpenAPI.NET writes the information with an `x-` extension because the target versionhas no native field. Other tools might ignore it.

ApproximatedOpenAPI.NET writes the closest older-version representation, but the exact originalsemantics aren't recoverable.Dropped or blockedOpenAPI.NET omits the information, writes an empty object, or throws when thetarget version can't represent the value safely.

## Default value considerations before serialization

Some object model properties use non-nullable `bool` values. After a document is loaded,OpenAPI.NET can't always distinguish between a field that was explicitly set to its default valueand a field that was omitted. When the writer omits default values, the explicit presence of thosefields can be lost even if you serialize back to the same OpenAPI version.This affects fields such as:

ﾉ**Expand table**

**Object****Boolean fields where explicit default presence can be lost**

    OpenApiParameterallowEmptyValue , allowReserved , deprecated , explode , required
**Object****Boolean fields where explicit default presence can be lost**

    OpenApiHeaderallowEmptyValue , allowReserved , deprecated , explode , requiredOpenApiOperationdeprecatedOpenApiRequestBodyrequiredOpenApiSchemaadditionalProperties when represented by AdditionalPropertiesAllowed ,
    deprecated , readOnly , unevaluatedProperties , writeOnly
    OpenApiSecuritySchemedeprecated
For example, an explicitly written `deprecated: false` can become indistinguishable from anomitted `deprecated` field.

## Serializing to OpenAPI 3.0

OpenAPI 3.0 is close to OpenAPI 3.1 and 3.2, but it doesn't support JSON Schema 2020-12,webhooks, reusable path items, media type components, the `query` HTTP method, or the

    querystring parameter location.
### Document-level information

ﾉ**Expand table**

**Source information****OpenAPI.NET behavior when writing 3.0****Result**`jsonSchemaDialect`Omitted.Dropped`webhooks`Omitted.Dropped`$self`Written as `x-oai-$self` .Preserved as an extension`components.pathItems`Omitted.Dropped`components.mediaTypes`Omitted.Dropped

### Paths, operations, and parameters

ﾉ**Expand table**

**Source information****OpenAPI.NET behavior when writing 3.0****Result**

Written under `x-oai-additionalOperations` .Preserved as anextension

Path item `query` operation or any othermethod that isn't native to OpenAPI 3.0

**Source information****OpenAPI.NET behavior when writing 3.0****Result**Parameter location `querystring`Throws because `querystring` is only

Blocked

supported in OpenAPI 3.2 and later.

Parameter style `cookie`Throws because this style is only supportedin OpenAPI 3.2 and later.

Blocked

### Components, responses, tags, examples, media types,and encodings

ﾉ**Expand table**

**Source information****OpenAPI.NET behavior when writing 3.0****Result**Response `summary`Written as `x-oai-summary` .Preserved as anextensionTag `summary` , `parent` , and `kind`Written as `x-oas-summary` , `x-oas-parent` , and

Preserved asextensions

    x-oas-kind .
Example `dataValue` and

    Written as x-oai-dataValue and x-oai-
Preserved asextensions

    serializedValue .
    serializedValue
Media type `itemSchema` ,

    Written as x-oai-itemSchema , x-oai-
Preserved asextensions

    itemEncoding , and prefixEncoding
    itemEncoding , and x-oai-prefixEncoding .
Encoding `encoding` , `itemEncoding` ,

    Written as x-oai-encoding , x-oai-
Preserved asextensions

    and prefixEncoding
    itemEncoding , and x-oai-prefixEncoding .
### Security schemes

ﾉ**Expand table**

**Source information****OpenAPI.NET behavior when writing 3.0****Result**

    mutualTLS security
Throws because `mutualTLS` is only supported in

Blocked

scheme

OpenAPI 3.1 and later.

OAuth 2

Written as `x-oauth2-metadata-url` .Preserved as anextension

    oauth2MetadataUrl
Security scheme

Written as `x-oai-deprecated` .Preserved as anextension

    deprecated
### Schema information

OpenAPI 3.0 uses an extended subset of JSON Schema rather than JSON Schema 2020-12.Schema conversion is the most common source of version-specific behavior.

ﾉ**Expand table**

**Source information****OpenAPI.NET behavior when****writing 3.0**

**Result**

    $schema , $id , $comment , $vocabulary , $defs ,
Omitted.Dropped

    $dynamicRef , $dynamicAnchorconstConverted to a one-value enum only
Approximatedor dropped

when no `enum` is already present. If

    enum is present, const is omitted.
    Multiple schema types, such as type: ["string",
The `type` field is omitted unless the

Dropped

only extra type is `null` .

    "integer"]
Nullable types, such as `type: ["string", "null"]`Written as `type: string` plus

Approximated

    nullable: true .
A schema that only allows `null`Written as `enum: [null]` .Approximated

    Numeric exclusiveMaximum or exclusiveMinimumConverted to maximum or minimum
Approximated

plus a boolean exclusive flag. If bothinclusive and exclusive bounds aremodeled, the older form can'tpreserve both independently.

`examples` on a schemaOmitted. The singular `example` field is

Dropped

preserved.

`dependentRequired`Omitted.Dropped

    unevaluatedProperties , patternProperties ,
    Written with x-jsonschema-*
Preserved asextensions

    $anchor , contentEncoding , contentMediaType ,
extension names.

    contentSchema , contains , maxContains ,minContains , propertyNames , dependentSchemas ,if , then , and else
## Serializing to OpenAPI 2.0

OpenAPI 2.0 has a substantially different document shape. It has one global `host` , one `basePath` ,a global `consumes` and `produces` model, `definitions` instead of `components.schemas` , body andform parameters instead of `requestBody` , and no native support for callbacks, links, content maps,OpenID Connect, mutual TLS, or most JSON Schema 2020-12 keywords.

### Document-level information

ﾉ**Expand table**

**Source information****OpenAPI.NET behavior when writing 2.0****Result**

    serversThe first server is used to write host and
Approximated

    basePath . Schemes are collected only from
servers with the same host, port, and path asthe first server. Server variables are substitutedbefore writing. Other server URLs and servermetadata are not preserved.

`jsonSchemaDialect` , `$self` , and `webhooks`Omitted.Dropped`components.schemas`Written as `definitions` .Preservednatively`components.parameters`Written as top-level `parameters` .Preservednatively`components.requestBodies`Converted to top-level body parameters whena parameter with the same key doesn't alreadyexist.

Approximated

`components.responses`Written as top-level `responses` .Preservednatively

    components.securitySchemesWritten as securityDefinitions , with the
Approximated

security scheme limitations described later.

    components.examples ,
Omitted.Dropped

    components.headers , components.links ,components.callbacks ,components.pathItems , andcomponents.mediaTypes
### Paths and operations

ﾉ**Expand table**

**Source information****OpenAPI.NET behavior when writing 2.0****Result**

Written as `x-summary` and `x-description` .Preserved asextensions

Path item `summary` and

    description
Path item `servers`Omitted.Dropped

**Source information****OpenAPI.NET behavior when writing 2.0****Result**

    trace , query , and other
Written under `x-oai-additionalOperations` .Preserved asextensions

non-OpenAPI 2.0operations

    Operation requestBodyConverted to a body parameter or to multiple formData
Approximated

parameters for `application/x-www-form-urlencoded` and

    multipart/form-data .
Operation request bodycontent media types

Written as operation-level `consumes` . The parameter

Approximated

schema comes from the first applicable media type.

Operation responsecontent media types

Written as operation-level `produces` . Response schemas

Approximated

and examples are derived from response content asdescribed later.

Operation callbacksOmitted.DroppedOperation serversOnly the URL schemes are written at the operation level.Host, path, variables, and other server information areomitted.

Approximated

### Request bodies, responses, parameters, headers, media types,and links

ﾉ**Expand table**

**Source information****OpenAPI.NET behavior when writing 2.0****Result**Request body objectConverted to a body parameter, or to form dataparameters for form and multipart content. Therequest body object itself doesn't exist in OpenAPI2.0.

Approximated

Request body description andrequired flag

Moved to the generated body or form parameters.Approximated

Request body content mapThe first content entry is used for schema andexamples; media type names are representedseparately in `consumes` .

Approximated

Request body media type

Omitted during request body conversion.Dropped

    example , encoding , itemSchema ,itemEncoding , prefixEncoding ,
and media type extensionsResponse content mapThe first content entry is used for the response

Approximated

    schema . Media type examples are written under
**Source information****OpenAPI.NET behavior when writing 2.0****Result**

`examples` or `x-examples` . Media type extensionsfrom the selected content entry are copied to theresponse.

Response `summary`Omitted.DroppedResponse linksOmitted.DroppedHeader `content` and `examples`Omitted. Header schema is flattened to OpenAPI2.0 header fields.Dropped orapproximatedParameter `content`Omitted. Parameters use the schema-basedOpenAPI 2.0 representation.

Dropped

Parameter `examples`Written as `x-examples` .Preserved as anextensionQuery array parameterserialization

Only some `style` and `explode` combinations are

Approximated

mapped to `collectionFormat` (` multi` , `pipes` , or

    ssv ). Other combinations are not recoverable.
Parameter location `querystring`Throws because it isn't supported in OpenAPI 2.0.BlockedParameter style `cookie`Throws because this style is only supported inOpenAPI 3.2 and later.

Blocked

Link objectsOmitted.DroppedMedia type and encoding objectsserialized directly

Omitted because OpenAPI 2.0 has no equivalentobjects.

Dropped

### Security schemes

ﾉ**Expand table**

**Source information****OpenAPI.NET behavior when writing 2.0****Result**HTTP Basic security schemeWritten as OpenAPI 2.0 `type: basic` .PreservednativelyHTTP token or other non-basic HTTPscheme

Written as an empty security scheme object.Dropped

OpenID Connect security schemeWritten as an empty security scheme object.DroppedMutual TLS security schemeWritten as an empty security scheme object.DroppedOAuth 2 flowsOnly one flow is selected, in this order: implicit,password, client credentials, authorization code.

Approximated

**Source information****OpenAPI.NET behavior when writing 2.0****Result**

Other flows are omitted.

OAuth 2 flow `refreshUrl` andextensions

Omitted because OpenAPI 2.0 OAuth flow fieldsonly include `flow` , `authorizationUrl` , `tokenUrl` ,and `scopes` .

Dropped

Security scheme `deprecated` ,

Omitted unless carried separately as customextensions.

Dropped

    bearerFormat , openIdConnectUrl , andoauth2MetadataUrl
### Schema information

ﾉ**Expand table**

**Source information****OpenAPI.NET behavior when****writing 2.0**

**Result**

    anyOf and oneOfIf allOf isn't already present, only the
Approximated

first `anyOf` schema is written as `allOf` ;

    if anyOf isn't present, only the firstoneOf schema is written as allOf .
Remaining alternatives are omitted.

`not`Omitted.Dropped

    Multiple schema types, such as type: ["string",
The `type` field is omitted unless the

Dropped

only extra type is `null` .

    "integer"]
Nullable typesWritten as `x-nullable: true` .Preserved asan extension`writeOnly` and schema `deprecated`Omitted.Dropped

    readOnly on a property that is also required by
Omitted because OpenAPI 2.0 doesn'tallow required read-only properties.

Dropped

the parent schemaDiscriminator mappingOnly the discriminator property nameis written. Mappings are omitted.

Approximated

    constConverted to a one-value enum only
Approximatedor dropped

when no `enum` is already present. If

    enum is present, const is omitted.
JSON Schema 2020-12 keywords such as

Omitted, except for the compatibilityextensions listed below.

Dropped

    $schema , $id , $comment , $vocabulary , $defs ,$dynamicRef , $dynamicAnchor ,dependentRequired , contentEncoding ,contentMediaType , contentSchema , contains ,
**Source information****OpenAPI.NET behavior when****writing 2.0**

**Result**

    maxContains , minContains , propertyNames ,dependentSchemas , if , then , and elseunevaluatedProperties and patternPropertiesWritten as x-jsonschema-
Preserved asextensions

    unevaluatedProperties and x-jsonschema-patternProperties .
Schema `examples`Omitted. The singular `example` field is

Dropped

preserved.

Array item serialization metadata fromparameter `style` and `explode`

Not available from reusable schemas,so `collectionFormat` might not be

Dropped

emitted for schema definitions.

## Reducing conversion gaps

Use the newest OpenAPI version that all of your downstream tools support. If you must serializeto OpenAPI 3.0 or 2.0, review the output before publishing it and avoid depending on extension-preserved data unless your consumers explicitly understand those extensions.For workflows that need round-tripping, keep the original source document as the canonicalartifact. Treat older-version output as a compatibility projection, not as a complete copy of thesource document.**Last updated on 07/15/2026**
